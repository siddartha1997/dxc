package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.model.Product;
import com.mongodb.WriteResult;
@Repository
public class ProductDAOImpl implements ProductDAO {
	@Autowired
	MongoTemplate mongoTemplate;
	
	public boolean addProduct(Product product) {
		System.out.println("Inside product"+product);
		mongoTemplate.save(product);
		return false;
	}

	

	@Override
	public Product getProduct(int productId) {
		return mongoTemplate.findById(productId, Product.class,"product");
	}

	@Override
	public boolean deleteProduct(int productId) {

		Product product=new Product();
		product.setProductId(productId);

		WriteResult writeResult= mongoTemplate.remove(product);
		System.out.println(writeResult);
		int rowsAffected=writeResult.getN();
		if(rowsAffected==0) {
		return false;}
		else
			return true;
	}

	@Override
	public boolean updateProduct(Product product) {
		mongoTemplate.save(product);
		return false;
	}

	@Override
	public boolean isProductExists(int productId) {

		Product product= mongoTemplate.findById(productId,Product.class,"product");
		if(product== null)
			return false;
		else
			return true;

		
	}

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Product.class);
	}

}
