package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.model.Movie;
import com.model.Product;
import com.mongodb.WriteResult;
@Repository

public class MovieDAOImpl implements MovieDAO {
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public boolean addMovie(Movie movie) {
		// TODO Auto-generated method stub
		mongoTemplate.save(movie);

		return false;
	}

	@Override
	public Movie getMovie(int movieID) {
		// TODO Auto-generated method stub
		return mongoTemplate.findById(movieID, Movie.class,"movie");
	}

	@Override
	public boolean deleteMovie(int movieID) {
		Movie movie=new Movie();
		movie.setMovieID(movieID);
		WriteResult writeResult= mongoTemplate.remove(movie);
		int rowsAffected=writeResult.getN();
		if(rowsAffected==0) {
			return false;}
			else
				return true;

		
	}

	@Override
	public boolean updateMovie(Movie movie) {
		mongoTemplate.save(movie);
		return false;
	}

	@Override
	public boolean isMovieExists(int movieID) {


		Movie movie= mongoTemplate.findById(movieID,Movie.class,"movie");
		if(movie== null)
			return false;
		else
			return true;
	}

	@Override
	public List<Movie> getMovies() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Movie.class);
	}

}
