package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Movie;
import com.service.MovieService;

@RestController
@RequestMapping("movie")
public class MovieController {

	@Autowired
	
	MovieService movieService;
	
	@GetMapping("/{movieID}")
	public Movie getMovie(@PathVariable("movieID")int mid) {
		System.out.println("Get movie Id"+mid);
		return movieService.getMovie(mid);
	}
	@GetMapping
	public List<Movie>getAllMovies() {
		System.out.println("All Movies called");
		return movieService.getMovies();
	}
	@DeleteMapping("/{movieID}")
	public boolean deleteMovie(@PathVariable("movieID")int mid) {
		System.out.println("Delete movieId"+mid);
		return movieService.deleteMovie(mid);
	}
	@PostMapping()
	public boolean saveMovie(@RequestBody Movie movie) {
		System.out.println("Saving product called");
		System.out.println(movie);
		return movieService.addMovie(movie);
	}
	@PutMapping()
	
	public boolean updateMovie(@RequestBody Movie movie) {
		System.out.println("Update movie called");
		System.out.println(movie);
		return movieService.addMovie(movie);
	}
	
}
