package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Product;
import com.model.Movie;

import com.service.MovieService;
import com.service.ProductService;

@RestController
@RequestMapping("product")
public class ProductController {

	@Autowired
	
	ProductService productService;
	
	@GetMapping("/{productId}")
	public Product getProduct1(@PathVariable("productId")int pId) {
		System.out.println("Get product Id"+pId);
		return productService.getProduct(pId);
	}
	@GetMapping
	public List<Product>getAllProducts() {
		System.out.println("All products called");
		return productService.getProducts();
	}
	@DeleteMapping("/{productId}")
	public boolean deleteProduct(@PathVariable("productId")int productId) {
		System.out.println("Delete productId"+productId);
		return productService.deleteProduct(productId);
	}
	@PostMapping()
	public boolean saveProduct(@RequestBody Product product) {
		System.out.println("Saving product called");
		System.out.println(product);
		return productService.addProduct(product);
	}
	@PutMapping()
	
	public boolean updateProduct(@RequestBody Product product) {
		System.out.println("Update product called");
		System.out.println(product);
		return productService.addProduct(product);
	}
	
}