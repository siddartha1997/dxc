package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MovieDAO;
import com.model.Movie;
@Service

public class MovieServiceImpl implements MovieService{
	@Autowired
	MovieDAO movieDAO;

	@Override
	public boolean addMovie(Movie movie) {
		// TODO Auto-generated method stub
		return movieDAO.addMovie(movie);
	}

	@Override
	public Movie getMovie(int movieID) {
		// TODO Auto-generated method stub
		return movieDAO.getMovie(movieID);
	}

	@Override
	public boolean deleteMovie(int movieID) {
		// TODO Auto-generated method stub
		return movieDAO.deleteMovie(movieID);
	}

	@Override
	public boolean updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		return movieDAO.updateMovie(movie);
	}

	@Override
	public boolean isMovieExists(int movieID) {
		// TODO Auto-generated method stub
		return movieDAO.isMovieExists(movieID);
	}

	@Override
	public List<Movie> getMovies() {
		// TODO Auto-generated method stub
		return movieDAO.getMovies();
	}

}
