package com.service;

import java.util.List;

import com.model.Movie;

public interface MovieService {
	public boolean addMovie(Movie movie);
	public Movie getMovie(int movieID);
	public boolean deleteMovie(int movieID);
	public boolean updateMovie(Movie movie);
	public boolean isMovieExists(int movieID);
	public List<Movie>getMovies();


}
