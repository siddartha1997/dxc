package com.dxc.userValidation.DAO;

import com.dxc.userValidation.model.*;;

public interface UserDAO {
	boolean validate = false;

	public   boolean validate(User user);
	

}
