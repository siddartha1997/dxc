package com.dxc.userValidation.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.userValidation.connection.*;
import com.dxc.userValidation.model.*;;



public class UserDAOImpl implements UserDAO{
	Connection connection=DbConnection.getConnection();
	private static final String Fetch_User="Select * from user where username=? and psaaword =?";
	public boolean validate(User user) {
		// TODO Auto-generated method stub
		boolean validate=false;
		PreparedStatement preparedStatement;
		try {
			preparedStatement=connection.prepareStatement(Fetch_User);
			preparedStatement.setString(1,user.getUserName());
			preparedStatement.setString(2,user.getPassword());
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				validate=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return validate;
	}

}