package com.dxc.userValidation.client;

import com.dxc.userValidation.client.*;;

public class UserMain {

	  public static void main(String[] args) {
		  UserApp app=new UserApp();
		  app.validate();
	       
		
	}
	       
	 
	    }
