package com.dxc.pasms.dao;

import java.util.ArrayList;
import java.util.List;

import com.dxc.pasms.Passenger;
import com.dxc.pms.Product;

public class PassengerDAOImpl implements PassengerDAO {

	public PassengerDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	List<Passenger> allPassenger = new ArrayList<Passenger>();
	@Override
	public Passenger getPassenger(int pnr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Passenger> getAllPassenger() {
		
		return allPassenger;
	}

	@Override
	public void addPassenger(Passenger passenger) {
	   allPassenger.add(passenger);

	}

	@Override
	public void deletePassenger(int pnr) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updatePassenger(Passenger passenger) {
		// TODO Auto-generated method stub

	}

}
