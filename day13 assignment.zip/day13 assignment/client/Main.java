package client;

import java.util.Scanner;

import com.dxc.pasms.Passenger;
import com.dxc.pasms.dao.PassengerDAO;
import com.dxc.pasms.dao.PassengerDAOImpl;


public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		PassengerDAO passengerDAO = new PassengerDAOImpl();
		while (true) {
			System.out.println("M E N U ");
			System.out.println("1. Add The passengers : ");
			System.out.println("2. Get All The passengers : ");
			System.out.println("3. E X I T");
			Scanner scanner = new Scanner(System.in);
			int choice = 0;
			System.out.println("Please enter your choice : (1-3)");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Please enter pnr :");
				int pnr = scanner.nextInt();
				System.out.println("Please enter passenger name :");
				String passengerName = scanner.next();
				System.out.println("Please enter source :");
				String source = scanner.next();
				System.out.println("Please enter berth :");
				int berth = scanner.nextInt();

				Passenger passenger = new Passenger(pnr, passengerName, source, berth);

				passengerDAO.addPassenger(passenger);
				break;
			case 2:

				System.out.println(passengerDAO.getAllPassenger());
				break;
			case 3:
				System.out.println("Thanks for using my app");
				System.exit(0);
			default:
				System.out.println("R U mad. Please enter (1-3)");
			}
		}

	}

}
