

public class ProductMain2 {

	
	public static void main(String args[]) {
		Product2 p1=new Product2();
		Product2 p2=new Product2();
		Product2 p3=new Product2();
		Product2 p4=new Product2();
		Product2 p5=new Product2();
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p4);
		System.out.println(p5);
		

	}
}
