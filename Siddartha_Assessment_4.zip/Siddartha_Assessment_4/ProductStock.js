import React, { Component } from 'react';
import ProductDetails from './ProductDetails'
import ProductDisplay from './ProductDisplay'


import { BrowserRouter as Router, Route, Link } from "react-router-dom";


class ProductStock extends Component {
    constructor(props) {
        super(props)
        this.state=({
            productList: [
                {
                    productId: 1001,
                    productName: 'Watch',
                    quantityOnHand: 2000,
                    price: 10000
                },
                {
                    productId: 1002,
                    productName: 'Mouse',
                    quantityOnHand: 29,
                    price: 180000
                },
                {
                    productId: 1003,
                    productName: 'Laptop',
                    quantityOnHand: 29,
                    price: 122
                },
                {
                    productId: 10113,
                    productName: 'Presenter',
                    quantityOnHand: 29,
                    price: 122
                },

                {
                    productId: 111003,
                    productName: 'Marker',
                    quantityOnHand: 29,
                    price: 122
                },
            ],
            productId:'',
            quantityOnHand:'',
            errors:{
                quantityOnHand:''
            }
        })
    }
    updateStock = (e) => {
        e.preventDefault()
        let productList = this.state.productList
        let toUpdateProductId = this.refs.productId.value
        let toupdateindex
        let toUpdateQuantityOnHand = this.refs.quantityOnHand.value
        console.log(toUpdateQuantityOnHand)
        let updateProduct
        productList.map((product, index) => {
            if (product.productId == toUpdateProductId) {
                updateProduct = this.state.productList[index]
                toupdateindex=index
                console.log(updateProduct.quantityOnHand)
            }
        }
        )
        this.updateProductMethod(toupdateindex, toUpdateQuantityOnHand)

    }
    updateProductMethod(toupdateindex, toUpdateQuantityOnHand) 
    {
        var arr = this.state.productList
        arr[toupdateindex].quantityOnHand = toUpdateQuantityOnHand
        this.setState({
            productList: arr
        })
    }
    doValidation=(e)=>{
        e.preventDefault()
        const{ref,value}=e.target;
        let errors=this.state.errors;
    
           if( errors.quantity=value < 0)
           errors.quantity='Quantity cant be negative';
         
       else if(errors.quantity=(value.length == 0))
       errors.quantity='Quantity cant be empty';
       
       else
       errors.quantity='';
    
    this.setState({
        errors,[ref]:value
    })
    }
    render() {
        let productList=this.state.productList;
        
        return (
            <div>
                
                <form >
                    <table>
                        <tr>
              <td>  Enter the Product Id to be updated :</td>
              <td> <input type="text" ref="productId" ></input> </td> 
                </tr>
               
                <tr>
              <td>  Enter the Quantity to be updated :</td>
              <td> <input type="text" ref="quantityOnHand" onChange={this.doValidation}></input> </td> 
              <span >{this.state.errors.quantity}</span>
                </tr>
                <tr><td>
                <button onClick={(e) => this.updateStock(e)}>UpdateStock</button>
                </td></tr>
                 </table>
                </form>
                {this.state.productList.map((product, index) =>
                    <Link to={`${this.props.match.url}/` + product.productName}>
                        <ProductDisplay render={({ match }) => match = { match }}
                            nn={index}
                            key={index}
                            product={product}
                        ></ProductDisplay>
                    </Link>

                )}
                <Route path={`${this.props.match.path}/:productName`}
                    render={({ match }) => match = { match }}
                    component={ProductDetails} />
               
                </div>
        );
    }
}

export default ProductStock;