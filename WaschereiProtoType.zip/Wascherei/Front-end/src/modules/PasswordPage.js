import React, { Component } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import Dataservice from '../service/Dataservice'
class PasswordPage extends Component {

    constructor(props){
        super(props)
        this.state={
            custUsername:'',
            custPassword:'',
            confirmPassword:'',
            custSecurityanswer:''
        }
        this.handlePassword=this.handlePassword.bind(this)
    }

    handlePassword(values){
        let errors={}
        console.log(values)
        if(values.custPassword===values.confirmPassword){
        let customer={
            custSecurityanswer:values.custSecurityanswer,
            custPassword:values.custPassword
        }
        let save=Dataservice.changePassword(values.custUsername,customer)
        console.log(save)
        alert("Password changed. Please login again.")
        this.props.history.push('/')
    }
        else{
           alert('passwords donot match')
        }
        return errors

    }
    render() {
        let{custUsername,custSecurityanswer,custPassword,confirmPassword}=this.state
        return (
            <div>
                <Formik initialValues = {{custUsername,custSecurityanswer,custPassword,confirmPassword}}
                        enableReinitialize = {true}
                        onSubmit = {this.onSubmit}
                        validateOnChange = {false}
                        validateOnBlur = {false}
                        onSubmit={this.handlePassword}>
                    <Form>

                    <fieldset className="form-group">
                        <label htmlFor="custUsername">Username</label>
                        <Field className="form-control col-sm-5" type="text" id="custUsername" name="custUsername" placeholder="Username" ></Field>
                    </fieldset>

                    <fieldset className="form-group">
                        <label htmlFor="custSecurityanswer">Security Question</label>
                        <Field className="form-control col-sm-5" type="text" id="custSecurityanswer" name="custSecurityanswer" placeholder="Father's birth place?" ></Field>
                    </fieldset>

                    <fieldset className="form-group">
                        <label htmlFor="custPassword">Password</label>
                        <Field className="form-control col-sm-5" type="password" id="custPassword" name="custPassword" placeholder="Password"  ></Field>
                    </fieldset>

                    <fieldset className="form-group">
                        <label htmlFor="confirmPassword">Confirm password</label>
                        <Field className="form-control col-sm-5" type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm password" ></Field>
                    </fieldset>

                    

                    <button type="submit" className="btn btn-outline-success" >Update</button>
                    
                        
                    </Form>
                </Formik>
                
            </div>
        );
    }
}

export default PasswordPage;