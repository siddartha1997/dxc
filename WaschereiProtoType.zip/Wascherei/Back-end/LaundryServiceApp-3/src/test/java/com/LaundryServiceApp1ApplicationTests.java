package com;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaundryServiceApp1ApplicationTests {

	@org.junit.Test
	void contextLoads() {
	}

}
