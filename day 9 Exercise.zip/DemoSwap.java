package day2;


import java.util.Scanner;

public class DemoSwap {
	Scanner sc=new Scanner(System.in);
	int num1;
	int num2;
		
		public void display()
		{
			System.out.println("Enter the first number");
			num1=sc.nextInt();
			

			System.out.println("Enter the second number");
			num2=sc.nextInt();
	System.out.println("Numbers before swapping are : num1="+num1+ ",num2:" +num2);
			num1=num1+num2;
			num2=num1-num2;
			num1=num1-num2;
			
	System.out.println("Numbers after swapping are : num1="+num1+ ",num2:" +num2);
	
		
		}
		public static void main(String args[])
		{
			DemoSwap d=new DemoSwap();
			d.display();
		}
}
