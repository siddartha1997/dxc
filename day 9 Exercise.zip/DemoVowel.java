package day2;

import java.util.Scanner;

public class DemoVowel {
	char c;
	Scanner sc=new Scanner(System.in);
	
	
	public void display1()
	{
		System.out.println("Enter the character");
		c=sc.next().charAt(0);
		if(c == 'a' || c=='e' || c=='i' || c=='o' || c=='u' )
		{
			System.out.println("Enter character is a vowel");
		}
		else
		{
			System.out.println("Enter character is a Consonant");
		}
			
			
	}
	public static void main(String args[])
	{
		
		DemoVowel d=new DemoVowel();
		d.display1();
	}
	

}
