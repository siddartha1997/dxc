function check()
            {
                var uname = document.getElementById("username").value;
                var password = document.getElementById("password").value;
                var s1 = document.getElementById("s1");
                var s2 = document.getElementById("s2");
                s1.innerHTML =""
                s2.innerHTML =""
                if((uname.length==0&&password.length==0)){
                    s1.innerHTML = "<font color=red>Please enter Username</font>"
                    s2.innerHTML = "<font color=red>Please enter Password </font>"
                    return false
                }
                else if(password.length==0){
                    s2.innerHTML = "<font color=red>Please enter Password </font>"
                    return false
                }
                else if(uname.length==0){
                    if((password.length<6)||(password.length>12))
                    {
                        s1.innerHTML = "<font color=red>Please enter Username</font>"
                        s2.innerHTML = "<font color=red> Password should begin with A</font>"
                        s2.innerHTML = "<font color=red>and Password Length should be between 6-12 and Password should begin with A</font>"
                        return false
                    }
                    else if((password.charAt(0)!='A'))
                    {
                        s1.innerHTML = "<font color=red>Please enter Username</font>"
                        s2.innerHTML = "<font color=red>Password should begin with A</font>"
                        return false
                    } 
                    else
                    {
                        s1.innerHTML = "<font color=red>Please enter Username</font>"
                        return false
                    }
                }
                else if(((password.length<6)||(password.length>12))&&(password.charAt(0)!='A'))
                {
                    s2.innerHTML = "<font color=red>Password Length should be between 6-12 and Password should begin with A</font>"
                    return false
                }
                else if((password.length<6)||(password.length>12))
                {
                    s2.innerHTML = "<font color=red>Password Length should be between 6-12</font>"
                    return false
                }
                else if(password.charAt(0)!='A')
                {
                    s2.innerHTML = "<font color=red>Password should begin with A</font>"
                    return false
                }
                else
                {
                    return true
                }
            }