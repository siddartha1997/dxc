var p1button=document.getElementById("p1")
var p2button=document.getElementById("p2")
var p1Display=document.querySelector("#p1Display")
var p2Display=document.querySelector("#p2Display")
var numInput=document.querySelector("input")
var winningScoreDisplay=document.querySelector("p span")
var resetButton=document.getElementById("reset")

p1score=0
p2score=0
gameOver=false
winningScore=5
p1button.addEventListener("click",function(){
    if(!gameOver){
    p1score++
    if(p1score==winningScore){
        gameOver=true
        p1Display.style.color="green"
    }
    p1Display.textContent=p1score
    }
    
})
p2button.addEventListener("click",function(){
    if(!gameOver){
    p2score++
    if(p2score==winningScore){
        gameOver=true
        p2Display.style.color="green"
    }
    p2Display.textContent=p2score
    }
    
})
numInput.addEventListener("change",function(){

    winningScoreDisplay.textContent=numInput.value
    winningScore=numInput.value
})
resetButton.addEventListener("click",function(){
    
    p1score=0
    p2score=0
    p1Display.textContent=0
    p1Display.style.color="orange"
    p2Display.textContent=0
    p2Display.style.color="orange"
    gameOver=false
})
p1button.addEventListener("mouseover",function(){
    p1button.classList.add("change")
})
p1button.addEventListener("mouseout",function(){
    p1button.classList.remove("change")
})